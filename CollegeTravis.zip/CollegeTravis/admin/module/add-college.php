<div class="row">
    <div class="col-md-12">
        <h2>Add Collage</h2>

    </div>
</div>
<!-- /. ROW  -->
<hr/>


<div class="form">
    <form action="#" method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label for="">Name</label>
            <input type="text" class="form-control" name="name">
        </div>
        <div class="form-group">
            <label for="">Year EST</label>
            <input type="text" class="form-control" name="year">
        </div>
        <div class="form-group">
            <label for="">Image</label>
            <input type="file" class="form-control" name="img">
        </div>
        <div class="form-group">
            <label for="">Subject Available</label>
            <textarea name="subject" id="editor1" cols="30" rows="10"></textarea>
        </div>
        <div class="form-group">
            <label for="">About</label>
            <textarea name="about" id="editor2" cols="30" rows="10"></textarea>
        </div>
        <button class="btn btn-primary" name="submit">Submit</button>
    </form>

</div>

<?php
    if (isset($_POST['submit'])){
        $use->saveCollege($_POST['name'],$_POST['year'],$_POST['subject'],$_POST['about'],$_FILES['img']);
        echo "<script>alert('Item successfully saved');location='./?page=colleges'</script>";
    }
?>