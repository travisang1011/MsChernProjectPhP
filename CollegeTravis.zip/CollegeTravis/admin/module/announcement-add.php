<?php $college = $use->getCollage($_GET['id']) ?>
<div class="row">
    <div class="col-md-12">
        <h2>Add Announcement College <?= $college['college_name'] ?></h2>

    </div>
</div>
<!-- /. ROW  -->
<hr/>

<div class="form">
    <form action="" method="post">
        <div class="form-group">
            <label for="">Title</label>
            <input type="text" class="form-control" name="name">
        </div>
        <div class="form-group">
            <label for="">Entry</label>
            <textarea name="text" id="editor1" cols="30" rows="10"></textarea>
        </div>
        <button name="submit" class="btn btn-primary">Submit</button>
    </form>
</div>

<?php
    if (isset($_POST['submit'])){
        $use->saveAnnouncement($_POST['name'],$_POST['text'],$_GET['id']);
        echo "<script>location='./?page=announcement-collage&id=".$_GET['id']."'</script>";
    }
?>




