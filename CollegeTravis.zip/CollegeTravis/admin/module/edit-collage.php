<div class="row">
    <div class="col-md-12">
        <h2>Add Collage</h2>

    </div>
</div>
<!-- /. ROW  -->
<hr/>
<?php
$college = $use->getCollage($_GET['id']);
?>

<div class="form">
    <form action="#" method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label for="">Name</label>
            <input type="text" class="form-control" name="name" value="<?= $college['college_name'] ?>">
        </div>
        <div class="form-group">
            <label for="">Year EST</label>
            <input type="text" class="form-control" name="year" value="<?= $college['college_year'] ?>">
        </div>
        <div class="form-group">
            <label for="">Image</label>
            <input type="file" class="form-control" name="img">
        </div>
        <div class="form-group">
            <label for="">Subject Available</label>
            <textarea name="subject" id="editor1" cols="30" rows="10"><?= $college['college_subject'] ?></textarea>
        </div>
        <div class="form-group">
            <label for="">About</label>
            <textarea name="about" id="editor2" cols="30" rows="10"><?= $college['college_about'] ?></textarea>
        </div>
        <button class="btn btn-primary" name="submit">Update</button>
    </form>

</div>

<?php
if (isset($_POST['submit'])) {
    $use->editCollege($_POST['name'], $_POST['year'], $_POST['subject'], $_POST['about'], $_FILES['img'], $_GET['id']);
    echo "<script>alert('Item successfully edited');location='./?page=colleges'</script>";
}
?><?php
