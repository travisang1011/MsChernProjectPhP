<?php $college = $use->getCollage($_GET['id']) ?>
<div class="row">
    <div class="col-md-12">
        <h2>Announcement College <?= $college['college_name'] ?></h2>

    </div>
</div>
<!-- /. ROW  -->
<hr/>

<div style="margin-bottom: 20px;" class="text-right">
    <a href="./?page=announcement-add&id=<?= $_GET['id'] ?>" class="btn btn-success">Add <i class="fa fa-plus"></i></a>
</div>
<div class="table">
    <table class="table table-bordered">
        <thead>
        <tr>
            <th width="100">#</th>
            <th>Title</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($use->getAnnouncements($_GET['id']) as $k => $announcement): ?>
        <tr>
            <td><?= $k+=1?></td>
            <td><?= $announcement['announcement_title'] ?></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>




