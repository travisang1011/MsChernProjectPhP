<?php
    if (isset($_GET['id'])){
        $use->deleteCollege($_GET['id']);
        echo "<script>alert('Deleted');location='./?page=colleges'</script>";
    }
?>
<div class="row">
    <div class="col-md-12">
        <h2>Colleges</h2>

    </div>
</div>
<!-- /. ROW  -->
<hr/>

<div style="margin-bottom: 20px;" class="text-right">
    <a href="./?page=add-college" class="btn btn-success">Add Item <i class="fa fa-plus"></i></a>
</div>
<div class="table">
    <table class="table table-bordered">
        <thead>
        <tr>
            <th>#</th>
            <th>Name</th>
            <th>Year Est</th>
            <th width="300">Action</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($use->getCollages() as $key => $collage): ?>
        <tr>
            <td><?= $key+=1; ?></td>
            <td><?=  $collage['college_name'] ?></td>
            <td><?=  $collage['college_year'] ?></td>
            <td>
                <a class="btn btn-info" href="./?page=edit-collage&id=<?= $collage['id_college'] ?>">Edit</a>
                <a class="btn btn-warning" href="./?page=announcement-collage&id=<?= $collage['id_college'] ?>">Announcement</a>
                <a class="btn btn-danger" href="./?page=colleges&id=<?= $collage['id_college'] ?>">Delete</a>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>



