<?php

?>
<div class="row">
    <div class="col-md-12">
        <h2>Users</h2>
        <h4>Showing list of users</h4>
    </div>
</div>
<!-- /. ROW  -->
<hr/>


<div class="table">
    <table class="table table-bordered">
        <thead>
        <tr>
            <th>#</th>
            <th>Name</th>
            <th>Email</th>
        </tr>
        </thead>
        <tbody>
            <?php foreach ($use->getUsers() as $k => $user): ?>
            <tr>
                <td><?= $k+=1; ?></td>
                <td><?= $user['user_name'] ?></td>
                <td><?= $user['user_email'] ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>



