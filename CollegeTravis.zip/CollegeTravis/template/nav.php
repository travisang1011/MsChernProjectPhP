<nav class="navbar navbar-expand-md navbar-light bg-dark">
    <a class="navbar-brand" href="#">Penang Best School Portal</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav mr-auto">
        </ul>
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" href="<?= base_url; ?>">Home</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?= base_url."colleges.php"; ?>">Colleges</a>
            </li>
            <?php if (empty($_SESSION['user'])): ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url."login.php"; ?>">Login</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url."register.php"; ?>">Register</a>
                </li>
            <?php else: ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url."profile.php"; ?>">Profile</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url."profile.php?logout"; ?>">Logout</a>
                </li>
            <?php endif; ?>
        </ul>
    </div>
</nav>