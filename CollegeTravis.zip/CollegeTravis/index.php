<?php
require "config/MainClass.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>C Portal Penang</title>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/my.css">

    
</head>
<body>
<?php include "template/nav.php"; ?>
<section class="hero">
    <div class="row justify-content-end">
        <div class="text col-md-8">
            <h3>In Penang, we have many good colleges</h3>
            <p>Check them out on our websites! see all the reviews and
subjects available before you pick yours!			</p>
        </div>
    </div>
</section>


<footer>
    &copy; C Portal 2020. All right reserved
</footer>

</body>
</html>