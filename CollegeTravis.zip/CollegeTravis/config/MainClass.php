<?php

session_start([1]);
define("base_url", "http://localhost:8080/CollegeTravis/");
error_reporting(0);

class MainClass
{

    function __construct()
    {
        $host = "localhost";
        $user = "root";
        $pw = "";
        $db = "college_portal";
        $this->db = new PDO("mysql:$host", $user, $pw);
        $this->db->exec("CREATE DATABASE IF NOT EXISTS $db");
        $this->db->exec("USE $db");
    }

    // function admin page for login
    function login($u, $p)
    {
        $pass = md5($p);
        $to = $this->db->query("SELECT * FROM admins where email='$u' AND password='$pass'");
        if ($to->rowCount() > 0) {
            $_SESSION['admin'] = $to->fetch(PDO::FETCH_ASSOC);
            return TRUE;
        } else {
            return FALSE;
        }
    }

    // login client
    function clientLogin($u, $p)
    {
        $pass = md5($p);
        $to = $this->db->query("SELECT * FROM users where user_email='$u' AND user_password='$pass'");
        if ($to->rowCount() > 0) {
            $_SESSION['user'] = $to->fetch(PDO::FETCH_ASSOC);
            return TRUE;
        } else {
            return FALSE;
        }
    }

    // register client
    function registerClient($name, $email, $pw, $phone, $gender)
    {
        $password = md5($pw);
        $stmt = $this->db->prepare("INSERT INTO `users`( `user_name`, `user_email`, `user_password`, `user_phone`, `user_sex`) VALUES (?,?,?,?,?)");
        $stmt->execute([$name, $email, $password, $phone, $gender]);
    }

    // save college item
    function saveCollege($name, $year, $subject, $about, $image)
    {
        $imgName = date('Yhsmid') . $image['name'];
        move_uploaded_file($image['tmp_name'], "../assets/images/" . $imgName);

        $stmt = $this->db->prepare("INSERT INTO `college_units`( `college_name`, `college_year`, `college_subject`, `college_about`,college_image) VALUES (?,?,?,?,?)");
        $stmt->execute([$name, $year, $subject, $about, $imgName]);
    }

    // delete college
    function deleteCollege($id)
    {
        $this->db->query("delete from college_units where id_college = '$id' ");
    }

    // show collages
    function getCollages()
    {
        return $this->db->query("select * from college_units order by id_college desc ")->fetchAll();
    }

    // show collages by id
    function getCollage($id)
    {
        return $this->db->query("select * from college_units where id_college = '$id' ")->fetch();
    }

    // edit college item
    function editCollege($name, $year, $subject, $about, $image, $id)
    {
        if ($image['error'] == 0) {
            // save with img
            $imgName = date('Yhsmid') . $image['name'];
            move_uploaded_file($image['tmp_name'], "../assets/images/" . $imgName);

            $stmt = $this->db->prepare("UPDATE `college_units` SET `college_name`=?,`college_year`=?,`college_subject`=?,`college_about`=?,`college_image`=? WHERE id_college = ? ");
            $stmt->execute([$name, $year, $subject, $about, $imgName, $id]);
        } else {
            $stmt = $this->db->prepare("UPDATE `college_units` SET `college_name`=?,`college_year`=?,`college_subject`=?,`college_about`=? WHERE id_college = ? ");
            $stmt->execute([$name, $year, $subject, $about, $id]);
        }

    }

    // save announcemtnt
    function saveAnnouncement($title, $text, $id)
    {
        $stmt = $this->db->prepare("INSERT INTO `announcements`( `announcement_title`, `announcement_text`, `announcement_college_id`) VALUES (?,?,?)");
        $stmt->execute([$title, $text, $id]);
    }


    // get all announce
    function getAnnouncements($idCollege)
    {
        return $this->db->query("select * from announcements where  announcement_college_id = '$idCollege' order by  id_announcement desc ")->fetchAll();
    }

    // get announce by id
    function getAnnouncement($id)
    {
        return $this->db->query("select * from announcements where  id_announcement = '$id'  ")->fetch();
    }

    // get all users
    function getUsers()
    {
        return $this->db->query("select * from users order by user_id desc ")->fetchAll();
    }

    // do a comment
    function saveComment($text, $idCollege, $idUser)
    {
        $stmt = $this->db->prepare("INSERT INTO `comments`( `comment_text`, `comment_user_id`, `comment_college_id`) VALUES (?,?,?)");
        $stmt->execute([$text, $idUser, $idCollege]);
    }

    // get Comment by collge
    function getCommentsByCollege($idCollge)
    {
        return $this->db->query("select * from comments c JOIN users u ON c.comment_user_id = u.user_id WHERE comment_college_id='$idCollge'  ")->fetchAll();
    }


}

$use = new MainClass();

